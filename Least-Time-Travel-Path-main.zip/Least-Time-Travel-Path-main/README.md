# List-Time-Travel-Path
1: This project is used for finding the shortest distance between two cities<br/>
2: Available Bus and Aeroplane services are used to find the least time travel path.<br/>
3: This is implemented by Dijkstra's algorithm.
